const mongoose = require('mongoose');
const ResumeSchema = new mongoose.Schema({
  name: String,
  email: String,
  skills: [String],
});
module.exports = mongoose.model('Resume', ResumeSchema);
