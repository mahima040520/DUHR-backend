const mongoose = require('mongoose');
const JDSchema = new mongoose.Schema({
  title: String,
  description: String,
  skillsRequired: [String],
});
module.exports = mongoose.model('JD', JDSchema);
