const JD = require('../models/JD');

exports.uploadJD = async (req, res) => {
  try {
    const { title, description, skillsRequired } = req.body;
    const jd = await JD.create({ title, description, skillsRequired });
    res.status(201).json({ message: 'JD uploaded', jd });
  } catch (err) {
    res.status(500).json({ error: 'JD upload failed' });
  }
};
