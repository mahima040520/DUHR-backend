const Resume = require('../models/Resume');
const resumeQueue = require('../queues/resumeQueue');

exports.uploadResume = async (req, res) => {
  try {
    const { name, email, skills } = req.body;
    const resume = await Resume.create({ name, email, skills });
    await resumeQueue.add('match-resume', { resumeId: resume._id, skills });
    res.status(201).json({ message: 'Resume uploaded & queued' });
  } catch (err) {
    res.status(500).json({ error: 'Resume upload failed' });
  }
};
