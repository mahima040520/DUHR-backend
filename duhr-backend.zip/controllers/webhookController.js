exports.receiveMatchingResult = async (req, res) => {
  const { resumeId, matchedJDId, score } = req.body;
  console.log('NLP Result:', { resumeId, matchedJDId, score });
  res.status(200).json({ message: 'Received' });
};
