const resumeQueue = require('../queues/resumeQueue');
resumeQueue.process('match-resume', async (job) => {
  const { resumeId, skills } = job.data;
  console.log('Processing resume for NLP:', resumeId, skills);
});
