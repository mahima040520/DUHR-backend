const express = require('express');
const router = express.Router();
const webhookCtrl = require('../controllers/webhookController');

router.post('/nlp-response', webhookCtrl.receiveMatchingResult);
module.exports = router;
