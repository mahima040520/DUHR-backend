const express = require('express');
const router = express.Router();
const jdCtrl = require('../controllers/jdController');

router.post('/upload', jdCtrl.uploadJD);
module.exports = router;
