const express = require('express');
const router = express.Router();
const resumeCtrl = require('../controllers/resumeController');

router.post('/upload', resumeCtrl.uploadResume);
module.exports = router;
