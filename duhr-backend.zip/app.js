const express = require('express');
const connectDB = require('./config/db');
const resumeRoutes = require('./routes/resumeRoutes');
const jdRoutes = require('./routes/jdRoutes');
const webhookRoutes = require('./routes/webhookRoutes');
require('dotenv').config();

const app = express();
connectDB();
app.use(express.json());
app.use('/api/resume', resumeRoutes);
app.use('/api/jd', jdRoutes);
app.use('/api/webhook', webhookRoutes);

module.exports = app;
